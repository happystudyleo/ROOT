# BirthdayPage

### Demo展示
---
[https://zjw1111.github.io/BirthdayPage/](https://zjw1111.github.io/BirthdayPage/)

## 相关fork说明
---
网页主要模板来自：[https://github.com/ayusharma/birthday](https://github.com/ayusharma/birthday)

图片放大脚本来自：[http://www.zhangxinxu.com/wordpress/?p=80](http://www.zhangxinxu.com/wordpress/?p=80)

## 新增
---
* 手机/电脑页面自适应
* 照片展示

## 修改
* js库脚本改为本地，方便本地播放
